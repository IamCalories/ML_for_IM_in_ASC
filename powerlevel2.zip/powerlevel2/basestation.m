function bs = basestation(ue,sys)

    group = sys.group;
    num_per_group = sys.num_per_group;
    % BS is in the center of each group
    bs_loc_x = zeros(group,1);
    bs_loc_y = zeros(group,1);
    for pattern = 1 : group
        bs_loc_x(pattern) = mean(ue.loc_x((pattern-1)*num_per_group+1 : pattern*num_per_group));
        bs_loc_y(pattern) = mean(ue.loc_y((pattern-1)*num_per_group+1 : pattern*num_per_group));
    end
    
    bs.loc_x = bs_loc_x;
    bs.loc_y = bs_loc_y;
    bs.height = 10;

end