function [idx, state_list,q_table] = check_state_exist(s, state_list, q_table, action_list)
    
    n_state = size(state_list,1);
    n_action = length(action_list);
    
    mark=0;
    for i=1:n_state
        if state_list(i,:)==s
            mark=1;
            idx=i;
        end
    end
    if mark==0
        tem = [state_list;s];
        state_list=tem;
        idx = n_state+1;
        q_table(idx,1:n_action)=rand(1,n_action);
    end
    
end
