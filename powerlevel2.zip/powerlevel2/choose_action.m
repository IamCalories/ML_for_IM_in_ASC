function [a, state_list, q_table] = choose_action(s, epsilon, state_list, q_table, action_list, scenario, group)
    
    % =======================
    % input parameters
    % s : current state
    % epsilon: greedy parameter
    % state_list: the state which has shown before
    % q_table: record the relationship between state and action
    % action_list: action_length = action_num*group
    % scenario: APC_RL->1, RL->0
    % =======================
    % output parameters
    % state_list, q_table: may be changed if the state is not exist
    % a: the action we choose
    % =======================
    
    n_action = length(action_list);
    % call the function "check_state_exist", return the index in the
    % state_list
    [s_idx, state_list, q_table] = check_state_exist(s, state_list, q_table, action_list);
    
    % [if random value(0~1) larger than "epsilon", than choose the action which is the largest value in q-table]
    % [else choose the action by random]
    if rand > epsilon
        state_action = q_table(s_idx,:);
        [~, idx] = sort(state_action);
        a = idx(n_action); % largest value is in the last
        count = 0;
        if scenario == 1
            while a <= group
                a = idx(n_action-count);
                count = count+1;
            end
        end
    else
        a = randperm(n_action,1);
        if scenario == 1
            while a <= group
                a = randperm(n_action,1);
            end
        end
    end
    
end