function [s_max, UR_ex_max] = exhaustive(sys,ue,bs)
    
    %Channel
    W = 10e6; % 10MHz;
    N0 = 10^(-174/10)/1000; % -174 dBm/Hz
    fc = 2;
    power = power_parameter;

    % MS Location 
    ue_loc_x = ue.loc_x;
    ue_loc_y = ue.loc_y;
    
    % BS Location 
    bs_loc_x = bs.loc_x;
    bs_loc_y = bs.loc_y;
 
    RSRP = zeros(length(ue_loc_x),length(bs_loc_x));
    for j = 1:length(ue_loc_x)
        for i = 1:length(bs_loc_x)
            d_2d = sqrt((ue_loc_x(j)-bs_loc_x(i))^2 + (ue_loc_y(j)-bs_loc_y(i))^2) + 1;  % we add the small value to avoid d_2d being zero
            RSRP(j,i) = RSRP_3D_UAV_UE(power.pt, bs.height, d_2d, fc);
        end
    end
    
    % Exhaustive �a�|
    group = sys.group;
    action_num = power.level;
    
    % list all possible state in all bs
    state = zeros(action_num^group-1, group);   
    for i = 1:action_num^group-1  % all off is unacceptable state
        for j = 1:group
            state(i,j) = mod((fix(i/(action_num^(j-1)))),action_num)/(action_num-1);
        end
    end
    
    UR_ex = zeros(action_num^group-1,1);
    
    % calculate the capacity of each state
    for iiiii = 1:action_num^group-1
        
        RSRP_thr = zeros(length(ue_loc_x),length(bs_loc_x));        
        for i = 1:length(ue_loc_x)
            for j = 1:length(bs_loc_x)
                if RSRP(i,j) < 10^(-25) %10^(-18) = -100dBm
                   RSRP_thr(i,j) = 0; 
                else
                   RSRP_thr(i,j) = RSRP(i,j)*state(iiiii,j);
                end
            end
        end
        
        bs_of_ue = zeros(1, length(ue_loc_x));
        num_per_bs = zeros(1, length(bs_loc_x));
        s1 = ones(length(ue_loc_x), length(bs_loc_x)); % �إ����ȥ���1���x�}
        s2 = zeros(length(ue_loc_x), length(bs_loc_x)); % �إ����ȥ���0���x�}
        for j = 1 : length(ue_loc_x)
            [~ , nearest] = max(RSRP_thr(j,:)); %�D�XRSRP�̤j��(��n������BS�A��)
            num_per_bs(nearest) = num_per_bs(nearest) + 1; %�֭p�C��BS��n��User
            bs_of_ue(j) = nearest; %bs_of_ue�Oue�b����bs�̭�
            s1(j, bs_of_ue(j)) = 0; % �N�s�u��BS�PUser�����ܦ�0�A��l1�Ҭ��z�Z 
            s2(j, bs_of_ue(j)) = 1; % �N�s�u��BS�PUser�����ܦ�1�A��l0�Ҭ��z�Z     
        end
        RSRP_signal = s2.* RSRP_thr;
        RSRP_interfer = s1.* RSRP_thr; % ��Ǥ��j����l��0.07dB(�A�Ȫ��j�פ��l��0.07dB;�z�Z���j�׷l��0.07dB); 

         %�p��SINR
        SINR = zeros(1, length(ue_loc_x));
        for j = 1 : length(ue_loc_x)
            S = sum(RSRP_signal(j,:));
            SUM_I = sum(RSRP_interfer(j,:));
            SINR(j) = S/(SUM_I+N0);
        end  

        WM = W/10^6; % MHz;
        UR_ex(iiiii) = sum((log2(1+SINR)./num_per_bs(bs_of_ue).*WM));
        
    end
    
    UR_ex_max = max(UR_ex);
    max_index = find(UR_ex(:)==UR_ex_max(1));
    max_index = max_index(1);
    ss = compress(bs_loc_x, bs_loc_y);
    s_max = [ss' state(max_index,:)];

end