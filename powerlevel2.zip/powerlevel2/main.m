close all;
clear all;
clc

sys = system_parameter;
power = power_parameter;

allon_UR=zeros(sys.times,1);
EX_UR=zeros(sys.times,1);
APC_UR=zeros(sys.times,1);
RL_UR=zeros(sys.times,1);

EX_s=zeros(sys.times,sys.group*2);
APC_s=zeros(sys.times,sys.group*2);
RL_s=zeros(sys.times,sys.group*2);
% % all on
% for k = 1:sys.times
%     ue = mobilestation(k);
%     bs = basestation(ue,sys);
%     s = compress(bs.loc_x, bs.loc_y);
%     sorted_s = sortbs(sys,s');
%     allon_UR(k,:) = efficiency([sorted_s, ones(1,12)],sys,ue,bs);
% end
% mean(allon_UR)

% Exhaustive
timer=tic;
for k = 1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    [EX_s(k,:), EX_UR(k,:)] = exhaustive(sys,ue,bs);
    EX_UR(k,:) = efficiency(EX_s(k,:),sys,ue,bs);
end
EX_timer=toc(timer);

% APC
timer=tic;
for k = 1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    APC_s(k,:) =  APC(k,sys,ue);
    APC_UR(k,:) = efficiency(APC_s(k,:),sys,ue,bs);
end
APC_timer=toc(timer);

% % RL training
% for k = 1:sys.times
%     scenario = 0; % RL
%     ue = mobilestation(k);
%     bs = basestation(ue,sys);
%     s = compress(bs.loc_x, bs.loc_y);
%     sorted_s = sortbs(sys,s');
% %    if k == 1
% %        q_table=[];
% %        state_list=[];
% %    else
%         q_table = dlmread('q_table.txt');
%         state_list = dlmread('state_list.txt');
% %    end
%     bound = efficiency([sorted_s, ones(1,12)],sys,ue,bs);
%     epsilon = 0.2;
%     for itr = 1:20
%         state = [sorted_s, ones(1,12)];
%         [state_list, q_table, next_bound] = RL_train(sys, ue, bs, state, state_list, q_table, bound, epsilon, scenario);
%         bound = next_bound;
%     end
%     dlmwrite('q_table.txt', q_table);
%     dlmwrite('state_list.txt', state_list);
%     
% end

% testing
q_table = dlmread('q_table.txt');
state_list = dlmread('state_list.txt');

timer=tic;
for k=1:sys.times
    scenario = 0; % RL
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    s = compress(bs.loc_x, bs.loc_y);
    sorted_s = sortbs(sys,s');
    
    num_action = power.level;
    action_list = 1:1:sys.group*num_action;
    RL_s(k, :) = [sorted_s, ones(1,12)];
    
    bound = efficiency(RL_s(k,:),sys,ue,bs);
    epsilon = 0.2;
    
    for itr = 1:5
       state = [sorted_s, ones(1,12)];
       [RL_s(k,:), state_list, q_table, next_bound] = RL_test(sys, ue, bs, state, state_list, q_table, bound, epsilon, RL_s(k, :), scenario);
       bound = next_bound;
    end
    RL_UR(k,:) = efficiency(RL_s(k,:),sys,ue,bs);
    
end
RL_timer = toc(timer);


% plot 
set(gcf,'position',[50 50 1000 800])  %left bottom width height

x=1:1:sys.times;
plot(x,EX_UR,'r')
hold on
plot(x,APC_UR,'--g')
hold on
plot(x,RL_UR,'-.b')

legend('Exhaustive','APC','RL');
xlim([1 sys.times])
title('User Data Rate')
xticks(1:1:sys.times)
ax1 = gca;
ax1.XGrid = 'on';
ax1.YGrid = 'off';

disp('===Exhaustive===')
EX_timer
EX_UR_avg = mean(EX_UR)

disp('===APC===')
APC_timer
APC_UR_avg = mean(APC_UR)

disp('===Q-learning===')
RL_timer
RL_UR_avg = mean(RL_UR)