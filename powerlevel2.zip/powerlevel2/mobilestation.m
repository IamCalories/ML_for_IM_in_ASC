function ue = mobilestation(k)

    ue_loc_x = csvread('ue_loc_total_x_DSC_12_trans.csv');
	ue_loc_y = csvread('ue_loc_total_y_DSC_12_trans.csv');
    
    ue.loc_x = ue_loc_x(k,:);
    ue.loc_y = ue_loc_y(k,:);
    
    ue.height = 1.5;

end