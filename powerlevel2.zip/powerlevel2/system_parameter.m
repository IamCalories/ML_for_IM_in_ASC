function sys = system_parameter
    
    sys.group = 12;
    sys.num_per_group = 5;
    sys.times = 36;
    
end