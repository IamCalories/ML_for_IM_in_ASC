function[s_next, reward, next_bound] = update_state(s,a,bound,count,sys,ue)
    
    group = sys.group;
    power = power_parameter;
    
    s_next = s;
    % action (0-group-1:off, group:group*2-1:1st_level_on, ...)
    % Therefore, state about bs_on_off is 0/(power.level-1),1/(power.level-1),2/(power.level-1),...
    s_next(mod(a,group)+group+1) = floor((a-1)/group)/(power.level-1);
    
    UR_ = efficiency(s_next,sys,ue);
    if UR_ >= bound
        next_bound = UR_;
        reward = next_bound;
    elseif UR_ == bound
        next_bound = UR_;
        reward = max((100-count)*(UR_-150)*0.1, 2);
    else
        next_bound = bound;
        reward = 0;
    end
    
end
