function state = APC(g,sys,ue)

    %Channel
    W = 10*10^6; % 10MHz;
    N0 = 10^(-174/10-10)/1000; % -174 dBm/Hz
    
    %Channel environmental parameters for Urban
    fc=900e6;

    %Power
    Pt = 1; % Picocell 30dBm = 1W
    P0 = 6.8; %pico cell : 6.8W
    Delta = 4; %pico cell : 4W
    P_active = P0+Delta*Pt;
    %Pt_tune = 0.1; % 20dBm
    Standby_sleep = 4.3; %pico cell : 4.3W
    %====

    Simulation_time = 360;
    time_interval = 10; %�C�j10s�����@�����

    % System area 120m x 120m

    %Drone Data
    H = 10; %���:���� - ����

    %User Data
    group = 12; %pattern_number
    num_per_group = 5; % UE per Group
    ue_loc_total_x = csvread('ue_loc_total_x_DSC_12_trans.csv');
	ue_loc_total_y = csvread('ue_loc_total_y_DSC_12_trans.csv');
    ue_num = group * num_per_group;

    %The Link Reliability
    SINR_th_dB = 1;
    SINR_th = 10^(SINR_th_dB/10);

    N = (Simulation_time/time_interval)+1;
    %N = 3;

    %User Location 
    ue_loc_x = ue_loc_total_x(g,:);
    ue_loc_y = ue_loc_total_y(g,:);
    ue_loc = [ue_loc_x ; ue_loc_y];
    ue_loc = ue_loc.';

    Drone_loc_intuitive = [];
    for pattern = 1 : group
      UE_postion = [];
      UE_postion = ue_loc([(pattern-1)*num_per_group+1 : pattern*num_per_group] , :);
      Drone_loc_intuitive(pattern,:) = [mean(UE_postion(:,1)) mean(UE_postion(:,2))];
    end  
    bs_loc_intuitive = [];
    bs_loc_intuitive_x = [];
    bs_loc_intuitive_y = []; 
    bs_loc_intuitive = Drone_loc_intuitive.';

    bs_loc_intuitive_x = bs_loc_intuitive(1,:);
    bs_loc_intuitive_y = bs_loc_intuitive(2,:);

    RSRP_total_intuitive = zeros(length(ue_loc),length(bs_loc_intuitive));

    for j = 1:length(ue_loc)
        for i=1:length(bs_loc_intuitive)
            d_2d = sqrt((ue_loc_x(j)-bs_loc_intuitive_x(i))^2 + (ue_loc_y(j)-bs_loc_intuitive_y(i))^2) + 1;
            RSRP_total_intuitive(j,i) = RSRP_3D_UAV_UE(Pt, H, d_2d, fc);
        end
    end

    RSRP_total_intuitive_thr = zeros(length(ue_loc),length(bs_loc_intuitive));
     for i = 1 : length(ue_loc)
        for j = 1 : length(bs_loc_intuitive)  
            if RSRP_total_intuitive(i,j) < 10^(-41) %10^(-18) = -100dBm
               RSRP_total_intuitive_thr(i,j) = 0; 
            else
               RSRP_total_intuitive_thr(i,j) = RSRP_total_intuitive(i,j); 
            end
        end
     end
    
    %RSRP_total_move_thr_turn = RSRP_total_move_thr.';
    bs_of_ue_n8 = zeros(1, length(ue_loc));
    n8 = zeros(1, length(bs_loc_intuitive));
    s17 = ones(length(bs_loc_intuitive),length(ue_loc)); % �إ����ȥ���1���x�}
    s18 = zeros(length(bs_loc_intuitive),length(ue_loc)); % �إ����ȥ���0���x�}
    for j = 1 : length(ue_loc)
        [~ , nearest] = max(RSRP_total_intuitive_thr(j,:)); %�D�XRSRP�̤j��(��n������BS�A��)
        n8(nearest) = n8(nearest) + 1; %�֭p�C��BS��n��User
        bs_of_ue_n8(j) = nearest; %bs_of_ue�Oue�b����bs�̭�
        s17(bs_of_ue_n8(j),j) = 0; % �N�s�u��BS�PUser�����ܦ�0�A��l1�Ҭ��z�Z 
        s18(bs_of_ue_n8(j),j) = 1; % �N�s�u��BS�PUser�����ܦ�1�A��l0�Ҭ��z�Z     
    end
    s17 = s17.'; %��m��ones(length(ue_loc),length(bs_loc))
    s18 = s18.'; %��m��zeros(length(ue_loc),length(bs_loc))

    RSRP_signal_intuitive = s18.* RSRP_total_intuitive_thr;
    RSRP_interfer_intuitive = s17.* RSRP_total_intuitive_thr; % ����l��5dB(�A�Ȫ��j�פ��l��5dB;�z�Z���j�׷l��5dB)

    % Similarity Matrix
    service_UE = zeros(length(s18),length(s18(1,:)));
    MI = zeros(length(s18),length(s18(1,:)));
    MI_total = zeros(length(s18(1,:)),length(s18(1,:)));
    for ii = 1 : length(s18(1,:).')
        for jj = 1 : length(s18(1,:).')
            service_UE = s18;
            MI(:,jj) = service_UE(:,ii).*RSRP_interfer_intuitive(:,jj);
            MI_total(ii,jj) = sum(MI(:,jj));
            if MI_total(ii,jj) == 0 
                MI_total(ii,jj) = 1; 
            end
        end
    end
    min_MI = min(min(MI_total).');

    Pref = zeros(length(s18(1,:)),1);
    for hh = 1 : length(s18(1,:).')
        Pref(hh,1) = mean(sum(MI_total(hh,:))-1);
    end
    Pref_avg = mean(Pref.');

    for ii = 1 : length(s18(1,:).')
        if MI_total(ii,ii) == 1 
            MI_total(ii,ii) = min_MI;
        end
    end

    % Responsibility Matrix
    Av = zeros(length(s18(1,:)),length(s18(1,:))); %�s�W1060627

    dd=1;
    for ddd = 1 :  dd %�s�W1060627
        Respon = zeros(length(s18(1,:)),length(s18(1,:)));
        QQ = [];
        for ii = 1 : length(s18(1,:).')
            for jj = 1 : length(s18(1,:).')
                Re_Ob = MI_total(ii,jj);
                cccc = 1 : length(s18(1,:).');
                %Respon(ii,jj) = Re_Ob - max(MI_total(ii,MI_total(ii,:)~=Re_Ob));
                QQ(ii,:) = Av(ii,find(cccc~=jj)) + MI_total(ii,find(cccc~=jj));
                Respon(ii,jj) = Re_Ob - max(QQ(ii,:)); %�s�W1060627
            end
        end 

        % Availability Matrix
        Undiagonal = zeros(length(s18(1,:))-1,1);
        Av = zeros(length(s18(1,:)),length(s18(1,:)));
        Undiagonal_Re = zeros(length(s18(1,:))-2,1);
        for ii = 1 : length(s18(1,:).')
            Diagonal = Respon(ii,ii);
            aaaa = 1 : length(s18(1,:).');
            Undiagonal = Respon(find(aaaa~=ii),ii);
            Undiagonal_add_Dia = 0;
            for jj = 1 : length(s18(1,:).')-1
                if Undiagonal(jj,1) > 0
                    Undiagonal_add_Dia = Undiagonal_add_Dia + Undiagonal(jj,1);
                end
            end
            Av(ii,ii) = Undiagonal_add_Dia;

            for hh = 1 : length(s18(1,:).')-1
                %Undiagonal_Ob = Undiagonal(hh,1);
                bbbb = 1 : (length(s18(1,:).')-1);
                Undiagonal_Re = Undiagonal(find(bbbb~=hh),1);
                Undiagonal_add_Undia = 0;
                for gg = 1 : length(s18(1,:).')-2
                    if Undiagonal_Re(gg,1) > 0
                        Undiagonal_add_Undia = Undiagonal_add_Undia + Undiagonal_Re(gg,1);
                    end
                end
                if hh >= ii
                    Av(hh+1,ii) = Undiagonal_add_Undia + Diagonal;
                else
                    Av(hh,ii) = Undiagonal_add_Undia + Diagonal;
                end
            end 
        end

        %Criterion Matrix
        Cri = zeros(length(s18(1,:)),length(s18(1,:)));
        exemplar = zeros(length(s18(1,:)),1);
        uex_index = zeros(length(s18(1,:)),length(s18(1,:)));
        Cri = Respon + Av;
        for ii = 1 : length(s18(1,:).')
            exemplar(ii,1) = max(Cri(ii,:));
            uex_index(ii,:) = Cri(ii,:)==exemplar(ii,1);
        end

        %Interference
        %��X���s�ߪ�cell
        j=0;
        uex_center_intuitive = [];
        for i = 1 : length(s18(1,:).')
            a = sum(uex_index(:,i));
            if a >= 2
                j=j+1;   
                uex_center_intuitive(1,j)=i;
                %ex_center(g,j)=i;
            end
        end  

         %��X���s�ߪ�cell - ��W�@�Ӥ]���s�� for FFR cluster
        j=0;
        uex_center_cluster = [];
        for i = 1 : length(s18(1,:).')
            a = sum(uex_index(:,i));
            if a >= 1
                j=j+1;   
                uex_center_cluster(1,j)=i;
                %ex_center(g,j)=i;
            end
        end  

    end
    ss=ones(1,12);
    ss(uex_center_intuitive)=0;
    
    % System area 120m x 120m
    unit=10;
    block=120/unit;
    
    %User Location 
    ue_loc_x = ue_loc_total_x(g,:);
    ue_loc_y = ue_loc_total_y(g,:);
    
    bs_loc_x=zeros(group,1);
    bs_loc_y=zeros(group,1);
    for i = 1 : group
        bs_loc_x(i) = ue_loc_x(i*5)/unit;
        bs_loc_y(i) = ue_loc_y(i*5)/unit;
    end
    bs_loc = [bs_loc_x  bs_loc_y];
    
    val=zeros(1,group); %location of BS
    for i=1:group
        val(i) = (bs_loc(i,1)-1)*block + (bs_loc(i,2)-1);
    end
    state = [val ss];
    
end
