function [opt_s, state_list, q_table, next_bound] = RL_test(sys, ue, bs, s, state_list, q_table, bound, epsilon, opt_s, scenario)
    
    power=power_parameter;
    group = sys.group;
    num_action = power.level;
    action_list=1:1:group*num_action;   %(1~cluster_num: off, cluster_num+1~2*cluster_num: 0.5on, cluster_num*2+1~cluster_num*3: on)
    count = 0;
    
    while(1)
        [a, state_list, q_table] = choose_action(s, epsilon, state_list, q_table, action_list, scenario, group);
        [s_next, r, next_bound] = update_state(s,a,bound,count,sys,ue,bs);
        if r>0
            opt_s = s_next;
            break;
        end
        if count>20
            break;
        end
        s = s_next;
        count = count+1;
    end
    
end
     