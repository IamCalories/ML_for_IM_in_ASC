function [state_list, q_table, next_bound] = RL_train(sys, ue, bs, s, state_list, q_table, bound, epsilon, scenario)
    
    power = power_parameter;
    group = sys.group;
    num_action = power.level;
    action_list = 1:1:group*num_action;   %(1~cluster_num: off, cluster_num+1~2*cluster_num: 0.5on, cluster_num*2+1~cluster_num*3: on)
    
    % =====
    % learning parameters
    gamma = 0.6;                                          
    lr = 0.1;
    % =====
    
    count = 0;
    while(1)
        [a, state_list, q_table] = choose_action(s, epsilon, state_list, q_table, action_list, scenario, group);
        [s_next, r, next_bound] = update_state(s,a,bound,count,sys,ue,bs);
        [state_list, q_table] = RL_learn(s, a, r, s_next, gamma, lr, state_list, q_table, action_list);
        if r>0||count>50
            break;
        end
        s=s_next;
        count = count+1;
    end
    
end
     