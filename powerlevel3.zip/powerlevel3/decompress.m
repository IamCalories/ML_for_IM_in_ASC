function out = decompress(in)
    
	% System area 120m x 120m
    unit=10;
    block=120/unit;
    
    out_x=fix(in/block);
    out_y=in-out_x*block;
    out_x=out_x+1;
    out_y=out_y+1;
    out_y=out_y*unit;
    out_x=out_x*unit;
    
    out.loc_x = out_x;
    out.loc_y = out_y;

end