function power = power_parameter

    % power
    power.pt = 1; % power transmission
    power.standby_sleep = 4.3;
    power.p0 = 6.8;
    power.delta = 4;
    power.level = 3;

end