function [state_list, q_table]=RL_learn(s,a,r,next_s,gamma,lr,state_list, q_table,action_list)
    
    [s_idx,state_list, q_table] = check_state_exist(s, state_list, q_table, action_list);
    [next_s_idx,state_list, q_table] = check_state_exist(next_s, state_list, q_table, action_list);
    q_predict = q_table(s_idx,a);
    q_target = r+gamma*max(q_table(next_s_idx,:));
    q_table(s_idx,a) = q_table(s_idx,a) + lr*(q_target-q_predict);
    
end