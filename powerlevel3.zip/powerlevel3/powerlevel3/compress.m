function out = compress(in_x,in_y)
	
    % System area 120m x 120m
    unit=10;
    block=120/unit;
    
    out = (in_x/unit-1)*block + (in_y/unit-1);

end