close all;
clear all;
clc

sys = system_parameter;
power=power_parameter;

allon_UR=zeros(sys.times,1);
EX_UR=zeros(sys.times,1);
APC_UR=zeros(sys.times,1);
RL_UR=zeros(sys.times,1);
APCRL_UR=zeros(sys.times,1);

EX_s=zeros(sys.times,sys.group*2);
APC_s=zeros(sys.times,sys.group*2);
RL_s=zeros(sys.times,sys.group*2);
APCRL_s=zeros(sys.times,sys.group*2);

% all on
for k = 1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    s = compress(bs.loc_x, bs.loc_y);
    sorted_s = sortbs(sys,s');
    allon_UR(k,:) = efficiency([sorted_s, ones(1,12)],sys,ue);
end
mean(allon_UR)

% Exhaustive
timer=tic;
for k = 1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    [EX_s(k,:), EX_UR(k,:)] = exhaustive(sys,ue,bs);
    EX_UR(k,:) = efficiency(EX_s(k,:),sys,ue);
end
EX_timer=toc(timer)
mean(EX_UR)

% APC
timer=tic;
for k = 1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    APC_s(k,:) =  APC(k);
    APC_UR(k,:) = efficiency(APC_s(k,:),sys,ue);
end
APC_timer=toc(timer)
mean(APC_UR)

% % APCRL training
% for k = 1:sys.times
%     scenario = 1; % APC_RL
%     ue = mobilestation(k);
%     bs = basestation(ue,sys);
%     APC_s(k,:) =  APC(k);
% %    if k == 1
% %        q_table=[];
% %        state_list=[];
% %    else
%         q_table = dlmread('apcrl_q_table.txt');
%         state_list = dlmread('apcrl_state_list.txt');
% %    end
%     bound = efficiency(APC_s(k,:),sys,ue);
%     epsilon = 0.2;
%     for itr = 1:30
%         state = APC_s(k,:);
%         [state_list, q_table, next_bound] = RL_train(sys, ue, state, state_list, q_table, bound, epsilon, scenario);
%         bound = next_bound;
%     end
%     dlmwrite('apcrl_q_table.txt', q_table);
%     dlmwrite('apcrl_state_list.txt', state_list);
%     
% end

% % APCRL testing
% q_table = dlmread('apcrl_q_table.txt');
% state_list = dlmread('apcrl_state_list.txt');
% for tt = 15:5:50
%     sum=0;
%     timer = tic;
% for ttt = 1:5
% for k=1:sys.times
%     scenario = 1; % APC_RL
%     ue = mobilestation(k);
%     bs = basestation(ue,sys);
%     APC_s(k,:) =  APC(k);
%     
%     num_action = power.level;
%     action_list=1:1:sys.group*num_action;
%     
%     APCRL_s(k, :) = APC_s(k,:);
%     bound = efficiency(APCRL_s(k,:),sys,ue);
%     epsilon = 0.2;
%     
%     for itr = 1:tt
%        state = APC_s(k,:);
%        [APCRL_s(k,:), state_list, q_table, next_bound] = RL_test(sys, ue, state, state_list, q_table, bound, epsilon, APCRL_s(k, :), scenario);
%        bound = next_bound;
%     end
%     APCRL_UR(k,:) = efficiency(APCRL_s(k,:),sys,ue);
%     
% end
% 
% sum = sum + mean(APCRL_UR);
% end
% tt
% APCRL_timer = toc(timer)/5
% sum/5
% end

q_table = dlmread('apcrl_q_table.txt');
state_list = dlmread('apcrl_state_list.txt');

itr =50;
scenario = 0; % RL
epsilon = 0.2;

bound = zeros(itr+1,sys.times,1);

for k=1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    bound(1,k) = efficiency(APC(k),sys,ue);
end

timer = tic;
for i = 1:itr
    i
    sum=0;
    for tt=1:10
        for k = 1:sys.times
            state = APC(k);
            ue = mobilestation(k);
            [state_list, q_table, bound(i+1,k)] = RL_test(sys, ue, state, state_list, q_table, bound(i,k), epsilon, scenario);
        end
        sum = sum + mean(bound(i+1,:));
    end
    toc(timer)/10
    sum/10
end

% % RL training
% for k = 1:sys.times
%     scenario = 0; % RL
%     ue = mobilestation(k);
%     bs = basestation(ue,sys);
%     s = compress(bs.loc_x, bs.loc_y);
%     sorted_s = sortbs(sys,s');
% %    if k == 1
% %        q_table=[];
% %        state_list=[];
% %    else
%         q_table = dlmread('q_table.txt');
%         state_list = dlmread('state_list.txt');
% %    end
%     bound = efficiency([sorted_s, ones(1,12)],sys,ue);
%     epsilon = 0.2;
%     for itr = 1:30
%         state = [sorted_s, ones(1,12)];
%         [state_list, q_table, next_bound] = RL_train(sys, ue, state, state_list, q_table, bound, epsilon, scenario);
%         bound = next_bound;
%     end
%     dlmwrite('q_table.txt', q_table);
%     dlmwrite('state_list.txt', state_list);
%     
% end

% testing
q_table = dlmread('q_table.txt');
state_list = dlmread('state_list.txt');

itr =50;
scenario = 0; % RL
epsilon = 0.2;

sorted_s = zeros(sys.times,sys.group);
bound = zeros(itr+1,sys.times,1);

for k=1:sys.times
    ue = mobilestation(k);
    bs = basestation(ue,sys);
    s = compress(bs.loc_x, bs.loc_y);
    sorted_s(k,:) = sortbs(sys,s');
    state = [sorted_s(k,:), ones(1,12)];
    bound(1,k) = efficiency(state,sys,ue);
end

timer = tic;
for i = 1:itr
    i
    sum=0;
    for tt=1:10
        for k = 1:sys.times
            state = [sorted_s(k,:), ones(1,12)];
            ue = mobilestation(k);
            [state_list, q_table, bound(i+1,k)] = RL_test(sys, ue, state, state_list, q_table, bound(i,k), epsilon, scenario);
        end
        sum = sum + mean(bound(i+1,:));
    end
    toc(timer)/10
    sum/10
end

% % plot 
% set(gcf,'position',[50 50 1000 800])  %left bottom width height
% 
% x=1:1:sys.times;
% plot(x,EX_UR,'r')
% hold on
% plot(x,APC_UR,'--g')
% hold on
% plot(x,APCRL_UR,'--k')
% hold on
% plot(x,RL_UR,'-.b')
% 
% legend('Exhaustive','APC','APC_RL','RL');
% xlim([1 sys.times])
% title('User Data Rate')
% xticks(1:1:sys.times)
% ax1 = gca;
% ax1.XGrid = 'on';
% ax1.YGrid = 'off';

% disp('===Exhaustive===')
% EX_timer
% EX_UR_avg = mean(EX_UR)
% 
% disp('===APC===')
% APC_timer
% APC_UR_avg = mean(APC_UR)

disp('===APCRL===')
APCRL_timer
APCRL_UR_avg = mean(APCRL_UR)

disp('===Q-learning===')
RL_timer
RL_UR_avg = mean(RL_UR)