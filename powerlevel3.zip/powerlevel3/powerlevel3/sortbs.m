function sorted_val = sortbs(sys,val)

    group = sys.group;
    for i=1:group-1
        s=i;
        for j=i+1:group
           if val(j) < val(s)
               s=j;
           end
        end
        tem = val(s);
        val(s) = val(i);
        val(i) = tem;
    end
    sorted_val = val;
    
end